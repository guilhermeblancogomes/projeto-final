export class suspensos {

    equipe: string;
    jogador: string;
    numero: number;
    categoria: string;
    criterio: number;
    jogos: number;
    motivo: string




    constructor(equipe: string,
        jogador: string,
        numero: number,
        categoria: string,
        criterio: number,
        jogos: number,
        motivo: string
        ) {

        this.equipe = equipe;
        this.jogador = jogador;
        this.numero = numero;
        this.categoria = categoria;
        this.criterio = criterio;
        this.jogos = jogos;
        this.motivo = motivo;
        
        
    }
}

