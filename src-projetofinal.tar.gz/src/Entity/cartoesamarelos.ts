export class cartoesamarelos {

    equipe: string;
    numero: number;
    jogador: string;
    data: number;
    tempo: number;
    adversario: string;
    arbitro: string;



    constructor(equipe: string,
        numero: number,
        jogador: string,
        data: number,
        tempo: number,
        adversario: string,
        arbitro: string
        ) {

        this.equipe = equipe;
        this.numero = numero;
        this.jogador = jogador;
        this.data = data;
        this.tempo = tempo;
        this.adversario = adversario;
        this.arbitro = arbitro;
        
        
    }
}

