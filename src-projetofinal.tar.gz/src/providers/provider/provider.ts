import { Http } from '@angular/http';
import { Injectable } from '@angular/core';

@Injectable()
export class ProviderGeral {

  constructor(public http: Http) {
    console.log('Hello ProviderGeral Provider');
  }

  getTabela() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/tabela.txt');
  }

  getClassificacaoGeral() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/classificacao-geral.txt');
  }

  getClassificacaoQuartasDeFinais() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/classificacao-4as-finais.txt');
  }

  getCartoesAmarelos() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/cartoes-amarelos.txt');
  }

  getCartoesVermelhos() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/cartoes-vermelhos.txt');
  }

  getArtilheiros() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/artilheiros.txt');
  }

  getSuspensos() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/suspensos.txt');
  }

  getJogos() {
    return this.http.get('http://www.futeboldospais.com.br/campeonato2018/json/jogos.txt');
  }


}
