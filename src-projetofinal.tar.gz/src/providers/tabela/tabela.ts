import { Injectable } from '@angular/core';
import { DatabaseProvider } from '../data-base/data-base';
import { tabela } from '../../Entity/tabela';
import { SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class TabelaProvider {

  constructor(private dbProvider: DatabaseProvider) {
    console.log('Hello TabelaProvider Provider');
  }

 
    public inserir(tabela: tabela) {
      return this.dbProvider.openDatabase().then((db: SQLiteObject) => {
        let sql = 'insert into tabela (rodada) values (?), (turno) values (?), (data) values (?), (horario) values (?), (equipe1) values (?), (equipe2) values (?), (categoria) values (?)';
        let parametros = [tabela.rodada, tabela.turno, tabela.data, tabela.equipe1, tabela.equipe2, tabela.categoria];
        return db.executeSql(sql, parametros).catch((e) => {
      });
    }).catch((e) => {
      console.log(e);
    });
  }

  public listar() {
    //abre a base
    return this.dbProvider.openDatabase()
      .then((db: SQLiteObject) => {
        //faz o select
        let sql = "SELECT * FROM tabela";
        return db.executeSql(sql, []).
          then((data: any) => {
            //se tiver alguma linha na tabela
            if (data.rows.lenght > 0) {
              let tabela: tabela[] = [];
              //pega cada linha e coloca num vetor
              for (let i = 0; i < data.rows.lenght; i++) {
                tabela.push(data.rows.item(i));
              }
              return tabela;
            }
            else
              //devolve vetor vazio se a tabela estiver vazia
              return [];
          });

      })
  }
}
