import { Injectable } from '@angular/core';
import { DatabaseProvider } from '../data-base/data-base';
import { classificacaogeral } from '../../Entity/classificacaogeral';
import { SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class ClassificacaoGeralProvider {

  constructor(private dbProvider: DatabaseProvider) {
    console.log('Hello ClassificacaoGeralProvider Provider');
  }

 
    public inserir(classificacaogeral: classificacaogeral) {
      return this.dbProvider.openDatabase().then((db: SQLiteObject) => {
        let sql = 'insert into classificacaogeral (equipe) values (?), (pontosGanhos) values (?), (jogos) values (?), (vitorias) values (?), (empates) values (?), (derrotas) values (?), (golsPro) values (?), (golsContra) values (?), (saldoGols) values (?), (cartoesAmarelos) values (?), (cartoesVermelhos) values (?)';
        let parametros = [classificacaogeral.equipe, classificacaogeral.pontosGanhos, classificacaogeral.jogos, classificacaogeral.vitorias, classificacaogeral.empates, classificacaogeral.derrotas, classificacaogeral.golsPro, classificacaogeral.golsContra, classificacaogeral.saldoGols, classificacaogeral.cartoesAmarelos, classificacaogeral.cartoesVermelhos];
        return db.executeSql(sql, parametros).catch((e) => {
      });
    }).catch((e) => {
      console.log(e);
    });
  }

  public listar() {
    //abre a base
    return this.dbProvider.openDatabase()
      .then((db: SQLiteObject) => {
        //faz o select
        let sql = "SELECT * FROM classificacaogeral";
        return db.executeSql(sql, []).
          then((data: any) => {
            //se tiver alguma linha na tabela
            if (data.rows.lenght > 0) {
              let classificacaogeral: classificacaogeral[] = [];
              //pega cada linha e coloca num vetor
              for (let i = 0; i < data.rows.lenght; i++) {
                classificacaogeral.push(data.rows.item(i));
              }
              return classificacaogeral;
            }
            else
              //devolve vetor vazio se a tabela estiver vazia
              return [];
          });

      })
  }
}
