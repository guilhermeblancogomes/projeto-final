import { Injectable } from '@angular/core';
import { DatabaseProvider } from '../data-base/data-base';
import { artilheiros } from '../../Entity/artilheiros';
import { SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class ArtilheirosProvider {

  constructor(private dbProvider: DatabaseProvider) {
    console.log('Hello ArtilheirosProvider Provider');
  }

 
    public inserir(artilheiros: artilheiros) {
      return this.dbProvider.openDatabase().then((db: SQLiteObject) => {
        let sql = 'insert into artilheiros (nome) values (?), (gols) values (?), (equipe) values (?), (numero) values (?), (posicao) values (?), (categoria) values (?), (cartoesAmarelos) values (?), (cartoesVermelhos) values (?)';
        let parametros = [artilheiros.nome, artilheiros.gols, artilheiros.equipe, artilheiros.numero, artilheiros.posicao, artilheiros.categoria, artilheiros.cartoesAmarelos, artilheiros.cartoesVermelhos];
        return db.executeSql(sql, parametros).catch((e) => {
      });
    }).catch((e) => {
      console.log(e);
    });
  }

  public listar() {
    //abre a base
    return this.dbProvider.openDatabase()
      .then((db: SQLiteObject) => {
        //faz o select
        let sql = "SELECT * FROM artilheiros";
        return db.executeSql(sql, []).
          then((data: any) => {
            //se tiver alguma linha na tabela
            if (data.rows.lenght > 0) {
              let artilheiros: artilheiros[] = [];
              //pega cada linha e coloca num vetor
              for (let i = 0; i < data.rows.lenght; i++) {
                artilheiros.push(data.rows.item(i));
              }
              return artilheiros;
            }
            else
              //devolve vetor vazio se a tabela estiver vazia
              return [];
          });

      })
  }
}
