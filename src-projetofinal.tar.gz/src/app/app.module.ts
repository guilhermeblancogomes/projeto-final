import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';

//importar as Page
import { JogosPage } from '../pages/jogos/jogos';
import { SumulaPage } from '../pages/sumula/sumula';
import { ArtilheirosPage } from '../pages/artilheiros/artilheiros';
import { ClassificacaoGeralPage } from '../pages/classificacaogeral/classificacaogeral';
import { TabelaPage } from '../pages/tabela/tabela';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import {SuspensosPage} from '../pages/suspensos/suspensos';
import {CartoesAmarelosPage} from '../pages/cartoesamarelos/cartoesamarelos';
import {CartoesVermelhosPage} from '../pages/cartoesvermelhos/cartoesvermelhos';
//import {ClassificacaoQuartasDeFinaisPage} from '../pages/classificacaoquartasdefinais/classificacaoquartasdefinais';

//importar os provider das outras telas.
import { ProviderGeral } from '../providers/provider/provider';
import { DatabaseProvider } from '../providers/data-base/data-base';
import { SQLite } from '@ionic-native/sqlite';
import { HttpModule } from '@angular/http';
import { JogosProvider } from '../providers/jogos/jogos';
import { ArtilheirosProvider } from '../providers/artilheiros/artilheiros';
import {TabelaProvider} from '../providers/tabela/tabela';
import {ClassificacaoGeralProvider} from '../providers/classificacaogeral/classificacaogeral';
import {SuspensosProvider} from '../providers/suspensos/suspensos';
import {CartoesAmarelosProvider} from '../providers/cartoesamarelos/cartoesamarelos';
import {CartoesVermelhosProvider} from '../providers/cartoesvermelhos/cartoesvermelhos';
import { RegrasPage } from '../pages/regras/regras';
import { IniciandoPage } from '../pages/iniciando/iniciando';
//import {ClassificacaoQuartasDeFinaisProvider} from '../providers/classificacaoquartasdefinais/classificacaoquartasdefinais';






@NgModule({
  declarations: [
    MyApp,
    JogosPage,
    SumulaPage,
    ArtilheirosPage,
    TabelaPage,
    ClassificacaoGeralPage,
    SuspensosPage,
    CartoesAmarelosPage,
    CartoesVermelhosPage,
    RegrasPage,
    IniciandoPage

  ],


  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    JogosPage,
    SumulaPage,
    ArtilheirosPage,
    TabelaPage,
    ClassificacaoGeralPage,
    SuspensosPage,
    CartoesAmarelosPage,
    CartoesVermelhosPage,
    RegrasPage,
    IniciandoPage
    
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: ErrorHandler, useClass: IonicErrorHandler },
    ProviderGeral,
    DatabaseProvider,
    JogosProvider,
    ArtilheirosProvider,
    TabelaProvider,
    ClassificacaoGeralProvider,
    SuspensosProvider,
    CartoesAmarelosProvider,
    CartoesVermelhosProvider,
    RegrasPage,
    IniciandoPage,
    SQLite
    //aqui importa os providers
    

  ]
})
export class AppModule { }
