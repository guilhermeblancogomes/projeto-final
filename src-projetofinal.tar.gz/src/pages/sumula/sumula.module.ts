import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SumulaPage } from './sumula';

@NgModule({
  declarations: [
    SumulaPage,
  ],
  imports: [
    IonicPageModule.forChild(SumulaPage),
  ],
})
export class SumulaPageModule {}
