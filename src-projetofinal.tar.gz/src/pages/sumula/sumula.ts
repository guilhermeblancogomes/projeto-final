import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { jogos } from '../../Entity/jogos';
import { AlertController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-sumula',
  templateUrl: 'sumula.html',
})
export class SumulaPage {
  public jogo : jogos;

  constructor(public navCtrl: NavController, public navParams: NavParams,public alertCtrl: AlertController) {
    this.jogo = this.navParams.get("jogoSelecionado");

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SumulaPage');
    console.log(this.jogo);
  }

  showConfirm() {
    let confirm = this.alertCtrl.create({
      title: 'Detalhes da partida',
      message: `
            Mostra informações refente ao jogo,
            Mostrando detalhes de como foi a partida. 

      `,
    });
    confirm.present();
  }
}
