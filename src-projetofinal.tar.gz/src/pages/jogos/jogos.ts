import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { JogosProvider } from '../../providers/jogos/jogos';
import { ProviderGeral } from '../../providers/provider/provider';
import { jogos } from '../../Entity/jogos';
import { SumulaPage } from '../sumula/sumula';
import { ClassificacaoGeralPage} from '../classificacaogeral/classificacaogeral';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-jogos',
  templateUrl: 'jogos.html',
})
export class JogosPage {

  realizado = "master";
  public lista = new Array<any>();
  public listaMaster = new Array<any>();
  public listaSenior = new Array<any>();

  constructor(public navCtrl: NavController, private provider: ProviderGeral, public susp: JogosProvider,public alertCtrl: AlertController) {
  }
  ionViewDidLoad() {
    this.provider.getJogos().subscribe(
      data => {
        const response = (data as any);
        const objeto_retorno = JSON.parse(response._body);
        //this.susp.inserir(objeto_retorno);
        this.lista = objeto_retorno;
        for (let item of this.lista) {
          if (item.categoria == 'Master') {
            this.listaMaster.push(item);
          } else {
            this.listaSenior.push(item);
          }

        }
      }

    )
  }
  public jogos(jogo: jogos): void{
    this.navCtrl.push(SumulaPage, { jogoSelecionado: jogo });
  }

  abrirTelaTabela(){
    this.navCtrl.setRoot(ClassificacaoGeralPage);
  }
  showConfirm() {
    let confirm = this.alertCtrl.create({
      title: 'Informações dos jogos',
      message: `
            Informações referentes ao jogos da rodada, 
            Mostrando jogos, datas, e resultados. 
            Classificação por "Master" ou "Sênior"
            Para mais informações das partidas, basta clicar na linha
            que mostrará todos os detalhes daquele jogo.

      `,
    });
    confirm.present();
  }
}
