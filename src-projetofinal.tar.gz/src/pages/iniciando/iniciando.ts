import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { JogosPage } from '../jogos/jogos';


@IonicPage()
@Component({
  selector: 'page-iniciando',
  templateUrl: 'iniciando.html',
})
export class IniciandoPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad IniciandoPage');
  }
  ngOnInit(){
    setTimeout(() => {
       
        this.navCtrl.setRoot(JogosPage);
    }, 3500);
}
}
