import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IniciandoPage } from './iniciando';

@NgModule({
  declarations: [
    IniciandoPage,
  ],
  imports: [
    IonicPageModule.forChild(IniciandoPage),
  ],
})
export class IniciandoPageModule {}
