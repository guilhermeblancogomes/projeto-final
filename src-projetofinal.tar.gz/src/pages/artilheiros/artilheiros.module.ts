import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ArtilheirosPage } from './artilheiros';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@NgModule({
  declarations: [
    ArtilheirosPage,
  ],
  imports: [
    IonicPageModule.forChild(ArtilheirosPage),
  ],
})

@Component({
  selector: 'page-artilheiros',
  templateUrl: 'artilheiros.html'
})
export class ArtilheirosPageModule {

}
