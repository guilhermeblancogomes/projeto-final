import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CartoesVermelhosPage } from './cartoesvermelhos';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@NgModule({
  declarations: [
    CartoesVermelhosPage,
  ],
  imports: [
    IonicPageModule.forChild(CartoesVermelhosPage),
  ],
})

@Component({
  selector: 'page-cartoesvermelhos',
  templateUrl: 'cartoesavermelhos.html'
})
export class CartoesVermelhosPageModule {

}
