import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegrasPage } from './regras';

@NgModule({
  declarations: [
    RegrasPage,
  ],
  imports: [
    IonicPageModule.forChild(RegrasPage),
  ],
})
export class RegrasPageModule {}
