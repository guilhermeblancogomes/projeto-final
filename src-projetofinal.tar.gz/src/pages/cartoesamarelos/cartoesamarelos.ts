import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CartoesAmarelosProvider } from '../../providers/cartoesamarelos/cartoesamarelos';
import { ProviderGeral } from '../../providers/provider/provider';
import { CartoesVermelhosPage } from '../cartoesvermelhos/cartoesvermelhos';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-cartoesamarelos',
  templateUrl: 'cartoesamarelos.html',
})
export class CartoesAmarelosPage {

  realizado = "master";
  public lista = new Array<any>();
  public listaMaster = new Array<any>();
  public listaSenior = new Array<any>();

  constructor(public navCtrl: NavController, private provider: ProviderGeral, public susp: CartoesAmarelosProvider,public alertCtrl: AlertController ) {
  }
  ionViewDidLoad() {
    this.provider.getCartoesAmarelos().subscribe(
      data => {
        const response = (data as any);
        const objeto_retorno = JSON.parse(response._body);
        //this.susp.inserir(objeto_retorno);
        this.lista = objeto_retorno;
        for (let item of this.lista) {
          if (item.categoria == 'Master') {
            this.listaMaster.push(item);
          } else {
            this.listaSenior.push(item);
          }

        }
        console.log(this.lista);
        console.log(objeto_retorno);
        console.log(this.susp.listar());

      }, error => {
        console.log(error);
      }
    )
  }
  abrirTelaCartoesVermelhos(){
    this.navCtrl.setRoot(CartoesVermelhosPage);
  }
  showConfirm() {
    let confirm = this.alertCtrl.create({
      title: 'Cartões tomados na rodada',
      message: `
            Informações referentes aos cartões marcados nos jogos, 
            Mostrando o jogadores com cartão .
            Time, Nome, Camisa, Jogos e os motivos. 

      `,
    });
    confirm.present();
  }
}