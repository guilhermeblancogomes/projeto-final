import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SuspensosPage } from './suspensos';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@NgModule({
  declarations: [
    SuspensosPage,
  ],
  imports: [
    IonicPageModule.forChild(SuspensosPage),
  ],
})

@Component({
  selector: 'page-suspensos',
  templateUrl: 'suspensos.html'
})
export class SuspensosPageModule {

}
