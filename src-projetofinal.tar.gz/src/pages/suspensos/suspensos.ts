import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SuspensosProvider } from '../../providers/suspensos/suspensos';
import { ProviderGeral } from '../../providers/provider/provider';


@Component({
  selector: 'page-suspensos',
  templateUrl: 'suspensos.html',
})
export class SuspensosPage {

  realizado = "master";
  public lista = new Array<any>();
  public listaMaster = new Array<any>();
  public listaSenior = new Array<any>();

  constructor(public navCtrl: NavController, private provider: ProviderGeral, public susp: SuspensosProvider) {
  }
  ionViewDidLoad() {
    this.provider.getSuspensos().subscribe(
      data => {
        const response = (data as any);
        const objeto_retorno = JSON.parse(response._body);
        //this.susp.inserir(objeto_retorno);
        this.lista = objeto_retorno;
        for (let item of this.lista) {
          if (item.categoria == 'Master') {
            this.listaMaster.push(item);
          } else {
            this.listaSenior.push(item);
          }

        }
        console.log(this.lista);
        console.log(objeto_retorno);
        console.log(this.susp.listar());

      }, error => {
        console.log(error);
      }
    )
  }
}